import React from 'react';
import LoginPage from './pages/LoginPage';

function App() {
  return (
    <div className="font-sans antialiased text-gray-900">
      <LoginPage />
    </div>
  );
}

export default App;