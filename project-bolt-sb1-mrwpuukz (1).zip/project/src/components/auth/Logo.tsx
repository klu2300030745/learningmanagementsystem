import React from 'react';
import { BookOpen } from 'lucide-react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  variant?: 'full' | 'icon';
}

const Logo: React.FC<LogoProps> = ({ size = 'md', variant = 'full' }) => {
  const sizes = {
    sm: {
      icon: 'h-6 w-6',
      text: 'text-lg',
    },
    md: {
      icon: 'h-8 w-8',
      text: 'text-xl',
    },
    lg: {
      icon: 'h-10 w-10',
      text: 'text-2xl',
    },
  };

  return (
    <div className="flex items-center">
      <BookOpen className={`text-blue-600 ${sizes[size].icon}`} />
      {variant === 'full' && (
        <span className={`ml-2 font-bold ${sizes[size].text} text-blue-600`}>
          EduHub
        </span>
      )}
    </div>
  );
};

export default Logo;